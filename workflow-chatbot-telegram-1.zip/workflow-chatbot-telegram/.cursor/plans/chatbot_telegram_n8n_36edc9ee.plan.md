---
name: Chatbot Telegram N8N
overview: Empacotar em Docker um N8N self-hosted com workflow importável que, via Telegram, recebe "cidade, estado", consulta OpenWeather (geocoding + clima) e responde em português com a temperatura atual.
todos:
  - id: docker-compose
    content: Criar docker-compose.yml, .env.example e .gitignore para N8N self-hosted
    status: completed
  - id: workflow-json
    content: Criar workflows/telegram-temperatura-brasil.json (parse, geocode+filtro UF, weather, respostas PT-BR)
    status: completed
  - id: readme
    content: Escrever README.md com setup BotFather, OpenWeather, WEBHOOK_URL, import e teste
    status: completed
isProject: false
---

# Chatbot Telegram de temperatura (N8N + Docker)

Projeto greenfield no repositório vazio [`/home/marcus/Documents/workflow-chatbot-telegram`](/home/marcus/Documents/workflow-chatbot-telegram). Tudo será versionado como Compose + workflow JSON + env de exemplo + README.

## Arquitetura

```mermaid
sequenceDiagram
  participant User as UsuarioTelegram
  participant TG as TelegramAPI
  participant N8N as N8N
  participant Geo as OpenWeatherGeo
  participant Weather as OpenWeatherCurrent

  User->>TG: "Campinas, SP"
  TG->>N8N: Webhook Telegram Trigger
  N8N->>N8N: Parse cidade e estado
  N8N->>Geo: GET /geo/1.0/direct?q=Campinas,BR
  Geo-->>N8N: candidatos com state
  N8N->>N8N: Filtra por UF/estado BR
  N8N->>Weather: GET /data/2.5/weather?lat&lon&units=metric&lang=pt_br
  Weather-->>N8N: temp e descricao
  N8N->>TG: Mensagem amigavel
  TG-->>User: "Em Campinas SP esta 23C..."
```

**Decisão de API:** o parâmetro `state` do Geocoding da OpenWeather é oficialmente só para EUA. Para o Brasil: buscar `q={cidade},BR&limit=5`, filtrar no Code node pelo campo `state` (ex.: `"São Paulo"`) usando um mapa UF → nome completo (`SP` → `São Paulo`), depois consultar o clima por `lat`/`lon`.

## Estrutura de arquivos

| Arquivo | Função |
|---|---|
| [`docker-compose.yml`](docker-compose.yml) | Serviço `n8n` (imagem oficial), volume persistente, porta `5678` |
| [`.env.example`](.env.example) | `OPENWEATHER_API_KEY`, `WEBHOOK_URL`, timezone, host |
| [`.gitignore`](.gitignore) | Ignora `.env` e dados locais |
| [`workflows/telegram-temperatura-brasil.json`](workflows/telegram-temperatura-brasil.json) | Workflow exportável/importável |
| [`README.md`](README.md) | Setup BotFather, chave OpenWeather, Compose, import e teste |

## Docker / N8N

- Imagem: `n8nio/n8n` (tag estável fixa, ex. `1.x`).
- Env importantes:
  - `GENERIC_TIMEZONE=America/Sao_Paulo` / `TZ=America/Sao_Paulo`
  - `WEBHOOK_URL` — URL pública (obrigatória para o Telegram Trigger; local: ngrok/cloudflared apontando para `5678`)
  - `OPENWEATHER_API_KEY` — usada no workflow via `$env.OPENWEATHER_API_KEY`
  - `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` — permite ler env nos nós
- Volume: `n8n_data:/home/node/.n8n`
- Mount read-only: `./workflows:/workflows` (facilita achar o JSON para importar)

Não incluir Postgres: SQLite embutido do N8N basta para este bot.

## Workflow N8N (nós)

1. **Telegram Trigger** — mensagens de texto.
2. **Switch**
   - `/start` ou `/ajuda` → mensagem de boas-vindas explicando o formato `Cidade, UF` (ex.: `Curitiba, PR` ou `Belo Horizonte, Minas Gerais`).
   - demais textos → fluxo de clima.
3. **Code (parse)** — exige `cidade, estado` (vírgula); normaliza espaços/acentos para match de estado; rejeita formato inválido.
4. **IF inválido** → Telegram Reply: instrução curta do formato.
5. **HTTP Request (Geocoding)**  
   `https://api.openweathermap.org/geo/1.0/direct?q={cidade},BR&limit=5&appid={{$env.OPENWEATHER_API_KEY}}`
6. **Code (filtro BR)** — escolhe o candidato cujo `state` casa com UF ou nome do estado; se nenhum, falha amigável.
7. **IF não encontrado** → “Não encontrei essa cidade no Brasil. Confira o nome e a UF.”
8. **HTTP Request (Current Weather)**  
   `https://api.openweathermap.org/data/2.5/weather?lat=...&lon=...&units=metric&lang=pt_br&appid=...`
9. **Code/Set (mensagem)** — resposta curta, ex.:  
   `Em Campinas (SP) está 23°C agora, com céu limpo.`
10. **Telegram** — `sendMessage` no mesmo `chatId`, respondendo à mensagem.

Credencial: apenas **Telegram Bot Token** (criada na UI do N8N após o primeiro acesso). A chave OpenWeather fica só no `.env`.

## Pré-requisitos manuais (documentados no README)

1. Criar bot no [@BotFather](https://t.me/BotFather) e copiar o token.
2. Criar conta em [OpenWeather](https://openweathermap.org/api) (plano free) e copiar a API key (pode levar alguns minutos para ativar).
3. Copiar `.env.example` → `.env`, preencher chave e `WEBHOOK_URL` pública.
4. `docker compose up -d` → abrir `http://localhost:5678`, criar usuário owner.
5. Credenciais → Telegram (colar token) → Importar o JSON → associar a credencial → **Activate**.
6. No Telegram, enviar `/start` e depois `São Paulo, SP`.

## Escopo explícito

- Só temperatura atual (não previsão, alertas nem multi-idioma).
- Respostas em pt-BR.
- Sem código de aplicação fora do N8N: a lógica vive no workflow JSON.
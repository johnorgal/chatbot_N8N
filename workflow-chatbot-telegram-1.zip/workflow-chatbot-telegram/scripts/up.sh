#!/usr/bin/env bash
# Sobe N8N + túnel Cloudflare e configura WEBHOOK_URL com HTTPS (exigido pelo Telegram).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -f .env ]]; then
  cp .env.example .env
  echo "Arquivo .env criado a partir de .env.example — preencha OPENWEATHER_API_KEY."
fi

# Carrega .env atual (para preservar OPENWEATHER_API_KEY etc.)
set -a
# shellcheck disable=SC1091
source .env
set +a

echo "→ Subindo N8N e túnel..."
docker compose up -d

echo "→ Aguardando URL HTTPS do Cloudflare Tunnel..."
URL=""
for _ in $(seq 1 60); do
  URL="$(docker compose logs tunnel 2>&1 | grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' | tail -1 || true)"
  if [[ -n "$URL" ]]; then
    break
  fi
  sleep 1
done

if [[ -z "$URL" ]]; then
  echo "Não foi possível obter a URL do túnel. Veja: docker compose logs tunnel" >&2
  exit 1
fi

# Garante barra final. Só WEBHOOK_URL precisa ser HTTPS (UI continua em localhost).
WEBHOOK_URL="${URL%/}/"

tmp="$(mktemp)"
awk -v wh="$WEBHOOK_URL" '
  BEGIN { u=0 }
  /^WEBHOOK_URL=/ { print "WEBHOOK_URL=" wh; u=1; next }
  { print }
  END { if (!u) print "WEBHOOK_URL=" wh }
' .env > "$tmp"
mv "$tmp" .env

echo "→ WEBHOOK_URL=$WEBHOOK_URL"
echo "→ Recriando N8N com a URL HTTPS..."
docker compose up -d --force-recreate n8n

echo
echo "Pronto."
echo "  UI local:      http://localhost:${N8N_PORT:-5678}"
echo "  Webhook HTTPS: $WEBHOOK_URL"
echo
echo "No N8N: desative e ative de novo o workflow Telegram para registrar o webhook."
